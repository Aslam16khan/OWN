package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class CompliancePage {

	public CompliancePage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
