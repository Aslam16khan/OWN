package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class CompaniesPage {

	public CompaniesPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
