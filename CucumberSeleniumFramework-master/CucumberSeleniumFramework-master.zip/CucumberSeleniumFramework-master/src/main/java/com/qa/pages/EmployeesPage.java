package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class EmployeesPage {

	public EmployeesPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
