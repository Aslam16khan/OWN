package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class SurveysPage {

	public SurveysPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
