package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class InvoicesPage {

	public InvoicesPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
