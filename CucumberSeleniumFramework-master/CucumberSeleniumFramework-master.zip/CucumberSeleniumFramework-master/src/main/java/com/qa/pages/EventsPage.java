package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class EventsPage {

	public EventsPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
