package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class AccountingPage {

	public AccountingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
