package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class ReportsPage {

	public ReportsPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
