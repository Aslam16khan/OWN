package com.qa.pages;

import org.openqa.selenium.WebDriver;

public class AdminPage {

	public AdminPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
	}

}
